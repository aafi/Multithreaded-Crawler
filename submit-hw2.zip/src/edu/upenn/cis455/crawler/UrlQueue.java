package edu.upenn.cis455.crawler;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

/**
 * Implements a blocking UrlQueue
 *
 */
public class UrlQueue {
	
	public static LinkedList<String> queue = new LinkedList<String>();
	
//	public static Set<String> visited = new HashSet<String>();
	
}
